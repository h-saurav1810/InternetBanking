<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login_css.scss">
</head>
<body>
    
    <div class='container'>
        <img src="/bankproject/back.png" width="30px" height="30px" onclick="location.href='bank-index.php'">
        <br>
        <br>
        <h1 style="font-size:25px">Login to your account. </h1>
        <br>

    <label class="input_label">Email</label>
    <input type="email" name="email">

    <br>
    <br>
    <label class="input_label"> Password</label>
    <input type="password" name="password">
    <p><a href=""> Forgot Password? </a> </p>

    <br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <br>
    <input type="submit" name="login" value="Login">
    <br>
    <br>
    <p>Not registered? <a href="bank_registration.php">Create an account</a></p>
    </div>



    


    
</body>
</html>