<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="registration_css.scss">
    <style>
        
    </style>
</head>
<body>

    <div class='right-container'>
    
    <form>
        <div class='container'>
        <div class='card'>
        <h1 style="font-size:22px" > Ready to create an account? </h1>
        <br>
        <h1 style="font-size:14px" > Fill in your information to register an account</h1>
        <br>
        <label class="input_label">Card Number</label><br>
        <input class='input' type="number" name="cardnumber" placeholder="Card Number">

        <br>
        <br>
        <label class="input_label">Fullname</label><br>
        <input class='input_field' type="text" name="firstname" placeholder ="First">
        <input class='input_field' type="text" name="lastname" placeholder ="Last">
        
        <br>
        <br>

        <label class="input_label"> Email Address </label><br>
        <input class='input_field' type="email" name="email" placeholder="test@test.com">

        <br>
        <br>


        <label class="input_label">Password</label><br>
        <input class="input_field" type="password" name="password" placeholder="********">

        <br>
        <br>

        <label class='input_label'>Confirm Password</label><br>
        <input class='input_field'type="password" name="confirmpassword" placeholder="********">

        <br>
        <br>

        <p> BY CLICKING 'REGISTER', YOU AGREE WITH THE TERMS & CONDITIONS AND THE PRIVACY STATEMENT</p>
        <br>

        
        </div>
        </div>
    
    <footer>
        
        <div class='set'>
        <form action="bank_login.php" method="post">
        <input type="button" onClick="location.href='bank_login.php'" value="Cancel">
    </form>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="submit" name="submit" value="Register">
        </div>
    </footer>
    </form>
</div>

</body>
</html>